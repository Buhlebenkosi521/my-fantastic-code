const city = "cityInput.value";
const apiKey = "cec85bc06c0dfd484345cb4a3249819e";
const apiUrl = "https://api.openweathermap.org/data/2.5/weather?units=metric";

let cityInput = document.querySelector("#cityInput");
let searchButton = document.querySelector("#searchButton");
let weather_icon = document.querySelector(".weather-icon");

let now = new Date();

async function displayWeather(city) {
  const response = await fetch(apiUrl + `&q=${city} + &appid=${apiKey}`);

  const data = await response.json();

  document.querySelector(".city").innerHTML = data.name;
  document.querySelector("#temperature").innerHTML =
    Math.round(data.main.temp) + "℃";
  document.querySelector(".humidity").innerHTML = data.main.humidity + "%";
  document.querySelector(".speed").innerHTML =
    Math.round(data.wind.speed) + "km/h";

  if (data.weather[0].main === "Clouds") {
    weather_icon.src = "https://openweathermap.org/img/wn/02d@2x.png";
  } else if (data.weather[0].main === "Clear") {
    weather_icon.src = "https://openweathermap.org/img/wn/01d@2x.png";
  } else if (data.weather[0].main === "Rain") {
    weather_icon.src = "https://openweathermap.org/img/wn/10d@2x.png";
  } else if (data.weather[0].main === "Drizzle") {
    weather_icon.src = "https://openweathermap.org/img/wn/09d@3xx.png";
  } else if (data.weather[0].main === "Snow") {
    weather_icon.src = "https://openweathermap.org/img/wn/13d@2x.png";
  } else if (data.weather[0].main === "Mist") {
    weather_icon.src = "https://openweathermap.org/img/wn/50d@2x.png";
  }
}

let d = document.querySelector("demo");
let hours = now.getHours();
let minutes = now.getMinutes();
let days = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
let day = days[now.getDay()];
demo.innerHTML = `${day},${hours}:${minutes}`;

searchButton.addEventListener("click", (e) => {
  e.preventDefault();
  displayWeather(cityInput.value);
});
